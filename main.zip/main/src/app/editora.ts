export class Editora {
    Editora: string;
    nome: string;

    constructor(Editora: string = '', nome: string = '') {
        this.Editora = Editora;
        this.nome = nome;
    }
}